#!/bin/bash

./remove_join.sh predict predict_t
./a.out predict_t > predict.pr

