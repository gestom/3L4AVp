#include <iostream>
#include <fstream>
#include <vector>
#include <boost/algorithm/string.hpp>

int main(int argc, char **argv) {
  std::fstream file;
  std::string line;
  
  float AP = 0, PR = 0;
  
  //for(float T = 0.99; T >= 0.0; T -= 0.01) {
  for(float T = 1.0; T >= 0.0; T -= 0.01) {
    float TP = 0, FN = 0, FP = 0, TN = 0, P = 0, R = 0;
    file.open(argv[1], std::fstream::in);
    while(std::getline(file, line)) {
      std::vector<std::string> params;
      boost::split(params, line, boost::is_any_of(" "));
      //std::cout << "Probability = " << params[2].c_str() << std::endl;
      
      if(atof(params[2].c_str()) >= T) {
	atof(params[0].c_str()) == 1 ? TP += 1.0 : FP += 1.0;
      } else {
	atof(params[0].c_str()) == 1 ? FN += 1.0 : TN += 1.0;
      }
    }
    file.close();
    TP == 0 ? P = 0 : P = TP/(TP+FP);
    TP == 0 ? R = 0 : R = TP/(TP+FN);
    
    AP += P*(R-PR);
    PR = R;
    //std::cout << T << " " << (2*P*R)/(P+R) << std::endl;
    std::cout << P << " " << R << std::endl;
    //std::cout << "T = " << T << ", P = " << (TP/(TP+FP)) << ", R = " << (TP/(TP+FN)) << ", TP = " << TP << ", FP = " << FP << ", FN = " << FN << ", Total = " << (TP+FN+FP+TN) << std::endl;
  }
  std::cout << "AP = " << AP << std::endl; 
  
  return 0;
}
