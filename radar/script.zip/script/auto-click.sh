#!/bin/bash

xdotool click --delay 2000 --repeat 100 1
