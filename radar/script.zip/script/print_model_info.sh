#!/bin/bash

while read line
do
    echo $line | awk '{print $2}' | sed 's/.*://' >> size
    echo $line | awk '{print $3}' | sed 's/.*://' >> dist
done < $1

sort -n size > size2
echo "[size] min =" $(head -n1 size2)", max =" $(tail -n1 size2)
sort -n dist > dist2
echo "[dist] min =" $(head -n1 dist2)", max =" $(tail -n1 dist2)

rm size size2 dist dist2
