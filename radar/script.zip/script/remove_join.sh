#!/bin/bash

sed '/labels/d' $1 > t
paste -d " " testset t > $2
rm t
